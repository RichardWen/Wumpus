﻿using System;

namespace $safeprojectname$
{
    public class Room
    {
        public bool[] doors;
        public Room(int numberofDoors)
        {
            
        }
    }
}
